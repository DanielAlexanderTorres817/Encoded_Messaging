# Arduino-Custom-Character
This repository holds arduino and processing code for printing Custom Characters on Adafruit HT16k33 8x8 Bicolor Led Matrix from software.


Full explaination of this project is available on [Instructables](https://www.instructables.com/id/Custom-Character-Generator-Adafruit-HT16k33-Matrix/).
